from django.apps import AppConfig


class CalappConfig(AppConfig):
    name = 'calapp'
